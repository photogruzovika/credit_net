// import Vue from 'vue'
// import Vuelidate from 'vuelidate'

Vue.use(Vuelidate)

Vue.config.productionTip = false

// export default {
// 	data() {
// 		return {
// 			email: '',
// 			password: '',
// 			repeatPassword: ''
// 		}
// 	}
// }